WIP: A simple program that writes a Twitter post

TO DO:
- Figure out how to cap ChatGPT message lengths to 280 characters to not interfere with Twitter length limits --- do we do tweet replies to make longer posts?
- Hone Spotify searches to always provide a new artist (Might need rails database for this)
- Figure out how to host on AWS and run a daily script
- Send email/ Discord for admin approval
- Refactor EVERYTHING
