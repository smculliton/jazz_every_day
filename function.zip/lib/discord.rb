require 'faraday'
require 'dotenv'
Dotenv.load

class DiscordService
  def self.conn
    
  end
end




{
  "content": "Hello, World!",
  "tts": false,
  "embeds": [{
    "title": "Hello, Embed!",
    "description": "This is an embedded message."
  }]
}